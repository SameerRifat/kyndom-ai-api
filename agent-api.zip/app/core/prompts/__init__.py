from .base import (
    prompt,
    instructions,
    extra_instructions_prompt,
    speech_to_speech_prompt,
    speech_to_speech_instructions,
    get_summary_prompt_with_context,
)