from phi.storage.assistant.postgres import PgAssistantStorage
from phi.memory.db.postgres import PgMemoryDb
from app.config import settings
from phi.storage.agent.postgres import PgAgentStorage
from phi.agent import AgentMemory

storage = PgAgentStorage(table_name="my_assistant", db_url=settings.DB_URL)
memory_db = AgentMemory(db=PgMemoryDb(db_url=settings.DB_URL, table_name="personalized_assistant_memory"))
# memory_db = AgentMemory(db=PgMemoryDb(db_url=settings.DB_URL, table_name="personalized_assistant_memory"), create_user_memories=True, create_session_summary=True)