from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.api.endpoints import chat, zhvi

app = FastAPI()
# app = FastAPI(title=settings.PROJECT_NAME, version=settings.VERSION)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(chat.router, prefix=settings.API_V1_STR)
app.include_router(zhvi.router, prefix=settings.API_V1_STR)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

########################################################################################

# from fastapi import FastAPI, APIRouter
# from phi.agent import Agent
# from phi.model.openai import OpenAIChat
# from phi.tools.duckduckgo import DuckDuckGo

# db_url = "postgresql://postgres.seiaxssosdtygakolqjc:Burewala_789@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres"

# app = FastAPI()
# router = APIRouter()

# agent = Agent(
#     model=OpenAIChat(id="gpt-4o"),
#     tools=[DuckDuckGo()],
#     description="You are a senior NYT researcher writing an article on a topic.",
#     instructions=[
#         "For a given topic, search for the top 5 links.",
#         "Then read each URL and extract the article text, if a URL isn't available, ignore it.",
#         "Analyse and prepare an NYT worthy article based on the information.",
#     ],
#     markdown=True,
#     show_tool_calls=True,
#     add_datetime_to_instructions=True,
#     debug_mode=True,
# )
# agent.print_response("Simulation theory", stream=True)

# @router.get("/")
# async def health_check():
#     agent.print_response("Simulation theory", stream=True)
#     return "The health check is successful!"

# app.include_router(router)

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app, host="0.0.0.0", port=8000)